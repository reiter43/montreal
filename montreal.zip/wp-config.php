<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'mon' );

/** Имя пользователя MySQL */
define( 'DB_USER', 'root' );

/** Пароль к базе данных MySQL */
define( 'DB_PASSWORD', '' );

/** Имя сервера MySQL */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '%f/DR}3O.Xwt0%&R22DVC_+B)zisyXI2Yk`.)*cV#3&DxuK^_([._09wwSn;R=Lt' );
define( 'SECURE_AUTH_KEY',  '4:/MY=iosa `gb |qKJ[z<bq_w3Za3!_:OL[/$=T/b2}fAOZY`)0iMB.3[7*JAGU' );
define( 'LOGGED_IN_KEY',    'M8YlmCW;9:jjxPS hO`z~as0lupOpiUVQ19gYf)uj2w&++,^0hn^,p)XU%kk#}wk' );
define( 'NONCE_KEY',        '12)/MQJbr3SOenlQ~#i0I|mQ!Cgv_,8jm^Z7z`1]irnou1sk:qp#RG3f>[xG~n1o' );
define( 'AUTH_SALT',        ';paomTelfs3~F&N~Mud{<_r0?ZIh+v0lVCZcjHu^7(DrW~yT%[u(hrAjks7.{>]b' );
define( 'SECURE_AUTH_SALT', 'aTvVB&~mG]}UnP)@df<T?H#LO$}5)25/WxV,03N@E-(<J$_NgeglD%9GF)oa,i}c' );
define( 'LOGGED_IN_SALT',   'Ve}Qv2gVekFAr&>gn03tD%W( AEG*/v?13n7Ot:[-1nY4)i{/.vF}cB=Ij(Q8S|*' );
define( 'NONCE_SALT',       '*cgMI]*t[LO%I[-52-@ms8w[{ s( -o:_eC!7H=H/r`bN)k[F[#NI_Kpc8BXhIMY' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once( ABSPATH . 'wp-settings.php' );

define('WPCF7_AUTOP', false );
